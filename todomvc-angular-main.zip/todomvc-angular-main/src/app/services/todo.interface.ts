export interface TodoInterface {
  id?: string;
  title?: string;
  completed?: boolean;
}
