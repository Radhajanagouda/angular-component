import { Component } from '@angular/core';

@Component({
  selector: 'app-copy-right',
  templateUrl: './copy-right.template.html'
})
export class CopyRightComponent {}
