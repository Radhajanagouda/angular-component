export default {
  publicDir: 'slides',
}
